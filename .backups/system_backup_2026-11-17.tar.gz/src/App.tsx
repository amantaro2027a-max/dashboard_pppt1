/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ProgramProvider, useProgramContext } from './context/ProgramContext';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { FlashCardsGroup1 } from './components/FlashCardsGroup1';
import { FlashCardsGroup2 } from './components/FlashCardsGroup2';
import { DashboardCharts } from './components/DashboardCharts';
import { StatusPeruntukanKewangan } from './components/StatusPeruntukanKewangan';
import { ProgramCatalog } from './components/ProgramCatalog';
import { AdminPage } from './components/AdminPage';
import { PeruntukanPage } from './components/PeruntukanPage';
import { PerbelanjaanPage } from './components/PerbelanjaanPage';
import { SubwaranPage } from './components/SubwaranPage';
import { BakiPeruntukanPage } from './components/BakiPeruntukanPage';
import { ProgramDetailModal } from './components/ProgramDetailModal';
import { ProgramFormModal } from './components/ProgramFormModal';
import { ExportModal } from './components/ExportModal';
import { WelcomePage } from './components/WelcomePage';
import { SelamatDatangPage } from './components/SelamatDatangPage';
import { DashboardBersepaduPage } from './components/DashboardBersepaduPage';
import { PengiraanBajetPage } from './components/PengiraanBajetPage';
import { AnalisisPegawaiPage } from './components/AnalisisPegawaiPage';
import { PusatPage } from './components/PusatPage';
import { JabatanPage } from './components/JabatanPage';
import { KlusterPage } from './components/KlusterPage';
import { IabAllPage } from './components/IabAllPage';
import { AdminMonitoringPage } from './components/AdminMonitoringPage';
import { AdminLogin } from './components/AdminLogin';
import { NotificationModal } from './components/NotificationModal';
import { getUserBannerInfo } from './utils/formatters';

import { Lock, ArrowRight } from 'lucide-react';

const DashboardContent: React.FC = () => {
  const { activeTab, currentUser, isSuperAdmin, pegawaiList, getPageAccessMode, setActiveTab } = useProgramContext();

  React.useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, [activeTab]);

  const bannerInfo = React.useMemo(
    () => getUserBannerInfo(currentUser, pegawaiList),
    [currentUser, pegawaiList]
  );

  if (activeTab === 'welcome') {
    return (
      <>
        <WelcomePage />
        <ProgramDetailModal />
        <ProgramFormModal />
        <ExportModal />
        <NotificationModal />
      </>
    );
  }

  const isLoginView = !currentUser && (activeTab === 'admin' || activeTab === 'dashboard');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      <div>
        <Header />

        {/* Page Hero Banner (disembunyikan pada halaman Log Masuk pelawat) */}
        {!isLoginView && (
          <section className="bg-white border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="w-full">
                  {/* Baris 1: Pengguna: ... */}
                  <div className="text-xs sm:text-sm tracking-wide leading-relaxed">
                    <span className="text-black font-black">Pengguna: </span>
                    <span className="text-blue-600 font-black">{bannerInfo.nama}</span>
                  </div>

                  {/* Baris 2: Jawatan: ... */}
                  <div className="text-xs sm:text-sm tracking-wide leading-relaxed mt-0.5">
                    <span className="text-black font-black">Jawatan: </span>
                    <span className="text-blue-600 font-black">{bannerInfo.jawatan}</span>
                  </div>

                  {/* Baris 3: Jabatan: ... */}
                  <div className="text-xs sm:text-sm tracking-wide leading-relaxed mt-0.5">
                    <span className="text-black font-black">Jabatan:</span>
                    {bannerInfo.jabatan ? (
                      <span className="text-blue-600 font-black"> {bannerInfo.jabatan}</span>
                    ) : null}
                  </div>

                  {/* Baris 4: Pusat: ... */}
                  <div className="text-xs sm:text-sm tracking-wide leading-relaxed mt-0.5">
                    <span className="text-black font-black">Pusat:</span>
                    {bannerInfo.pusat ? (
                      <span className="text-blue-600 font-black"> {bannerInfo.pusat}</span>
                    ) : null}
                  </div>

                  <div className="pt-3 border-t border-slate-100 mt-3">
                    <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                    {activeTab === 'selamatDatang'
                      ? 'Selamat Datang — Profil Pegawai & Akaun'
                      : activeTab === 'dashboard'
                      ? 'Dashboard Interaktif Masa Kini IAB'
                      : activeTab === 'bersepadu'
                      ? 'Dashboard Bersepadu & Analitik Eksekutif'
                      : activeTab === 'perincian'
                      ? 'Perincian & Katalog Program Pusat'
                      : activeTab === 'analisisPegawai'
                      ? 'Analisis Pegawai Mengikut Program'
                      : activeTab === 'iabAll'
                      ? 'Profil, Perbandingan & Rumusan IAB All'
                      : activeTab === 'klusterProfesional'
                      ? 'Kluster Khidmat Profesional'
                      : activeTab === 'klusterLatihan'
                      ? 'Kluster Khidmat Latihan'
                      : activeTab === 'pusat'
                      ? 'Profil, Perbandingan & Rumusan Pusat'
                      : activeTab === 'jabatan'
                      ? 'Profil, Perbandingan & Rumusan Jabatan'
                      : activeTab === 'pengiraan'
                      ? 'Pengiraan Bajet Program & Pakej Hotel'
                      : activeTab === 'peruntukan'
                      ? 'Pengurusan Peruntukan'
                      : activeTab === 'perbelanjaan'
                      ? 'Pemantauan Perbelanjaan Sebenar'
                      : activeTab === 'subwaran'
                      ? 'Pengurusan Sub Waran Peruntukan'
                      : activeTab === 'baki'
                      ? 'Pemantauan Baki Peruntukan Kewangan'
                      : activeTab === 'monitoring'
                      ? 'Admin Monitoring Dashboard'
                      : !currentUser
                      ? 'Log Masuk Akaun Pengguna & Pentadbir'
                      : isSuperAdmin
                      ? 'Portal Pengurusan Pentadbir (Admin)'
                      : 'Akses Terhad'}
                  </h1>
                <p className="text-xs text-slate-600 mt-1 max-w-3xl">
                  {activeTab === 'selamatDatang'
                    ? 'Paparan rasmi profil pegawai, muat naik gambar pasport, masa & tarikh semasa, serta pengemaskinian kata laluan akaun anda.'
                    : activeTab === 'dashboard'
                    ? 'Sistem pemantauan dan analisis statistik perancangan aktiviti, sumber kewangan, dan status pelaksanaan program rasmi IAB (Mod Paparan Sahaja).'
                    : activeTab === 'bersepadu'
                    ? 'Portal eksekutif bersepadu: Prestasi Keseluruhan, Petunjuk Prestasi Utama (KPI), Risikan Kewangan, Papan Pengumuman & Visualisasi Interaktif.'
                    : activeTab === 'perincian'
                    ? 'Katalog terperinci maklumat program, agihan peruntukan objek sebagai (OS21, OS24, OS27, OS29), dan profil pegawai pengurus (Mod Paparan Sahaja).'
                    : activeTab === 'analisisPegawai'
                    ? 'Analisis terperinci beban tugas, visualisasi data, dan pencapaian pelaksanaan program bagi setiap pegawai mengikut Pusat, Jabatan, Jawatan & Status.'
                    : activeTab === 'iabAll'
                    ? 'Paparan menyeluruh semua Kluster, Pusat, Jabatan, dan Pegawai IAB beserta visualisasi infografik, perbandingan antara kluster/pusat/jabatan dan rumusan status.'
                    : activeTab === 'klusterProfesional'
                    ? 'Paparan terperinci Kluster Khidmat Profesional: senarai Pusat, Jabatan, Pegawai, visualisasi infografik, perbandingan dan rumusan pelaksanaan program.'
                    : activeTab === 'klusterLatihan'
                    ? 'Paparan terperinci Kluster Khidmat Latihan: senarai Pusat, Jabatan, Pegawai, visualisasi infografik, perbandingan dan rumusan pelaksanaan program.'
                    : activeTab === 'pusat'
                    ? 'Paparan terperinci Pusat, senarai jabatan & pegawai di bawah pusat, visualisasi infografik, perbandingan antara jabatan, dan rumusan keseluruhan.'
                    : activeTab === 'jabatan'
                    ? 'Paparan terperinci Jabatan, senarai pegawai di bawah jabatan, visualisasi infografik setiap pegawai, perbandingan & rumusan mengikut status program.'
                    : activeTab === 'pengiraan'
                    ? 'Kalkulator pengiraan bajet Makan Minum, Dobi, dan Pakej Hotel (beserta SST 6% & 8%). Pengguna boleh mengisi sel kuning; kadar kos seunit (RM) dikawal oleh Super Admin.'
                    : activeTab === 'peruntukan'
                    ? 'Penetapan peruntukan Fasa 1, Fasa 2 dan seterusnya mengikut Sumber Kewangan & pecahan Kod OS bagi kegunaan rasmi IAB.'
                    : activeTab === 'perbelanjaan'
                    ? 'Pemantauan rekod belanja sebenar (OS21, OS24, OS27, OS29) bagi program berstatus SELESAI & TANGGUNG mengikut Sumber Kewangan Induk.'
                    : activeTab === 'subwaran'
                    ? 'Pendaftaran dan pemantauan peruntukan yang diagihkan / disubwaran kepada PTJ Cawangan IAB, JPN, PPD, IPG, dan KV mengikut Sumber Kewangan & pecahan OS.'
                    : activeTab === 'baki'
                    ? 'Analisis baki peruntukan menyeluruh: Peruntukan (Page Peruntukan) − Belanja Sebenar (Page Perbelanjaan) = Penjimatan; Penjimatan − Subwaran = Baki Bersih Akhir.'
                    : activeTab === 'monitoring'
                    ? 'Real-time user activity audit log, trend analytics, security incident alerts, user activity profiles & official audit report generation (Asia/Kuala_Lumpur).'
                    : !currentUser
                    ? 'Sila masukkan ID Pengguna dan Kata Laluan untuk mengakses halaman dan maklumat mengikut tahap kebenaran anda.'
                    : isSuperAdmin
                    ? 'Pusat kawalan pendaftaran & kemaskini program, pengurusan akaun ID Admin mengikut Jabatan, serta kemaskini data induk (Master Data).'
                    : 'Halaman pengurusan pentadbir hanya boleh diakses oleh Super Admin sahaja.'}
                </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'selamatDatang' ? (
            /* HALAMAN SELAMAT DATANG SELEPAS LOG MASUK */
            <SelamatDatangPage />
          ) : activeTab === 'dashboard' ? (
            !currentUser ? (
              <AdminLogin />
            ) : getPageAccessMode('DASHBOARD PROGRAM') === 'none' ? (
              <div className="max-w-4xl mx-auto py-16 px-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-12 shadow-sm text-center">
                  <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-5 border-4 border-rose-50">
                    <Lock className="w-8 h-8" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                    Akses Dihadkan · Pengguna Diberi Kebenaran Sahaja
                  </span>
                  <h2 className="text-2xl font-black text-slate-900 mt-4 tracking-tight">
                    Dashboard Program (IAB)
                  </h2>
                  <p className="text-slate-600 text-sm max-w-lg mx-auto mt-2 leading-relaxed">
                    Anda tidak mempunyai kebenaran untuk mengakses halaman <strong>Dashboard Program</strong>. Sila hubungi Super Admin untuk menetapkan kebenaran dalam <strong>KEBENARAN VIEW/PAPAR PAGE</strong>.
                  </p>
                  <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => setActiveTab('selamatDatang')}
                      className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
                    >
                      <span>Kembali ke Selamat Datang</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* PAGE 1 – DASHBOARD PROGRAM PUSAT (VIEW ONLY) */
              <div>
                {/* Filter Bar with Sumber Kewangan */}
                <FilterBar showTahunBulan={true} showStatusFilter={true} />

                {/* Prestasi Pelaksanaan Program */}
                <FlashCardsGroup1 />

                {/* STATUS PERUNTUKAN KEWANGAN (Group Baharu Latar Soft Green) */}
                <StatusPeruntukanKewangan />

                {/* Status Pelaksanaan Program */}
                <FlashCardsGroup2 />

                {/* Analytics & Distribution Visualisations */}
                <DashboardCharts />
              </div>
            )
          ) : activeTab === 'bersepadu' ? (
            /* PAGE 2 – DASHBOARD BERSEPADU & ANALITIK EKSEKUTIF PPPT */
            <DashboardBersepaduPage />
          ) : activeTab === 'perincian' ? (
            /* PAGE 3 – PERINCIAN PROGRAM (VIEW ONLY) */
            <ProgramCatalog />
          ) : activeTab === 'analisisPegawai' ? (
            /* PAGE BARU – ANALISIS PEGAWAI MENGIKUT PROGRAM */
            <AnalisisPegawaiPage />
          ) : activeTab === 'iabAll' ? (
            /* PAGE BARU – PAGE IAB ALL */
            <IabAllPage />
          ) : activeTab === 'klusterProfesional' ? (
            /* PAGE BARU – KLUSTER KHIDMAT PROFESIONAL */
            <KlusterPage targetKlusterKey="KLUSTER KHIDMAT PROFESIONAL" />
          ) : activeTab === 'klusterLatihan' ? (
            /* PAGE BARU – KLUSTER KHIDMAT LATIHAN */
            <KlusterPage targetKlusterKey="KLUSTER KHIDMAT LATIHAN" />
          ) : activeTab === 'pusat' ? (
            /* PAGE BARU – PAGE PUSAT */
            <PusatPage />
          ) : activeTab === 'jabatan' ? (
            /* PAGE BARU – PAGE JABATAN */
            <JabatanPage />
          ) : activeTab === 'pengiraan' ? (
            /* PAGE BARU – PENGIRAAN BAJET (AKSES PELAWAT) */
            <PengiraanBajetPage />
          ) : activeTab === 'peruntukan' ? (
            /* PAGE 4 – PERUNTUKAN FASA (SUPER ADMIN) */
            <PeruntukanPage />
          ) : activeTab === 'perbelanjaan' ? (
            /* PAGE 5 – PERBELANJAAN (SUPER ADMIN) */
            <PerbelanjaanPage />
          ) : activeTab === 'subwaran' ? (
            /* PAGE 6 – SUBWARAN (SUPER ADMIN) */
            <SubwaranPage />
          ) : activeTab === 'baki' ? (
            /* PAGE 7 – BAKI PERUNTUKAN (SUPER ADMIN) */
            <BakiPeruntukanPage />
          ) : activeTab === 'monitoring' ? (
            /* PAGE BARU – ADMIN MONITORING DASHBOARD */
            <AdminMonitoringPage />
          ) : (
            /* PAGE 3 – ADMIN */
            <AdminPage />
          )}
        </main>
      </div>

      {/* Modals */}
      <ProgramDetailModal />
      <ProgramFormModal />
      <ExportModal />
      <NotificationModal />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">Dashboard Pusat IAB</span>
            <span>·</span>
            <span>Institut Aminuddin Baki (IAB)</span>
          </div>
          <div>
            <span>Aplikasi ini dibangunkan oleh Pusat Pembangunan dan Pengurusan Teknologi (PPPT)</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('ErrorBoundary caught error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-md w-full bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-xl space-y-4">
            <h2 className="text-xl font-bold text-rose-400">Ralat Memuat Aplikasi</h2>
            <p className="text-xs text-slate-300 font-mono bg-slate-950/70 p-3 rounded-lg text-left overflow-x-auto">
              {this.state.error?.message || 'Ralat tidak diketahui'}
            </p>
            <div className="flex gap-2 justify-center pt-2">
              <button
                onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-bold text-white transition-colors cursor-pointer"
              >
                Tetapkan Semula &amp; Muat Semula
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <ProgramProvider>
        <DashboardContent />
      </ProgramProvider>
    </ErrorBoundary>
  );
}
